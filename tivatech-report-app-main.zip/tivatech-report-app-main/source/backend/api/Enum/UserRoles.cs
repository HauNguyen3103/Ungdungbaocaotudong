﻿namespace HauCK.Enum
{
    public static class UserRoles
    {
        public const string Admin = "Admin";
        public const string Leader = "Leader";
        public const string Crew = "Crew";
    }
}
