﻿namespace HauCK.Enum
{
    public enum Status
    {        
        Required,
        Pending,        
        Complete,
        Error
    }
}
