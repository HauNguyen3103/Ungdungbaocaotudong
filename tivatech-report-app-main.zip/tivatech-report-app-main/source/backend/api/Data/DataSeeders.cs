﻿using HauCK.Entiities;
using Microsoft.EntityFrameworkCore;

namespace HauCK.Data;

public class DataSeeders
{
    public static async Task SeedRolesAndAdminAsync(IServiceProvider service)
    {

    }
}